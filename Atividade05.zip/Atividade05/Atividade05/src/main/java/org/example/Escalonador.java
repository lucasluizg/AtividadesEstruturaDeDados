package org.example;

public class Escalonador {

    private FilaCircular<Processo> fila = new FilaCircular<>(10);
    private static final int QUANTUM = 2;
    private boolean pausaHabilitada = true;

    public Escalonador() {
        this.pausaHabilitada = true;
    }

    public Escalonador(boolean pausaHabilitada) {
        this.pausaHabilitada = pausaHabilitada;
    }

    public void tempo(String nome) {
        System.out.println(nome + " executando...");
        if (pausaHabilitada) {
            try {
                Thread.sleep(2000); 
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void checarProcesso(Processo[] processos) {
        int tempoAtual = 0;
        int totalProcessos = processos.length;
        int processosFinalizados = 0;

        while (processosFinalizados < totalProcessos) {

            checarChegadas(processos, tempoAtual);

            if (fila.estaVazia()) {
                System.out.println("Tempo " + tempoAtual + ": Fila está vazia!");
                tempoAtual++;
                continue;
            }

            Processo atual = fila.desinfileirar();
            atual.setStatus("EXECUTANDO");

            tempo(atual.getNome());

            int executadas = Math.min(QUANTUM, atual.getInstrucoesRestantes());
            atual.setInstrucoesRestantes(atual.getInstrucoesRestantes() - executadas);

            System.out.println(atual.getNome() + " executou " + executadas + " instruções. Restam: " + atual.getInstrucoesRestantes());

            if (atual.getInstrucoesRestantes() <= 0) {
                atual.setStatus("TERMINADO");
                System.out.println(atual.getNome() + " terminou!\n");
                processosFinalizados++;
            } else {
                atual.setStatus("PRONTO");
                fila.enfileirar(atual);
            }

            tempoAtual++;
        }

        System.out.println("Todos os processos foram concluídos!");
    }

    private void checarChegadas(Processo[] processos, int tempoAtual) {
        for (Processo p : processos) {
            if (p.getTempoChegada() == tempoAtual && "AGUARDANDO".equals(p.getStatus())) {
                System.out.println("Tempo " + tempoAtual + ": " + p.getNome() + " chegou e entrou na fila.");
                p.setStatus("PRONTO");
                fila.enfileirar(p);
            }
        }
    }

    public FilaCircular<Processo> getFila() {
        return fila;
    }

    public void setFila(FilaCircular<Processo> fila) {
        this.fila = fila;
    }
}