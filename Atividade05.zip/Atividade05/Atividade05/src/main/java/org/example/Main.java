package org.example;

public class Main {
    public static void main(String[] args) {

        boolean pausaHabilitada = true;

        // Se passar o argumento "--rapido", "-r", "--fast" ou "-f", desabilita a pausa de 2 segundos para execução rápida
        if (args.length > 0 && (args[0].equalsIgnoreCase("--rapido") || args[0].equalsIgnoreCase("-r") ||
                                args[0].equalsIgnoreCase("--fast") || args[0].equalsIgnoreCase("-f"))) {
            pausaHabilitada = false;
        }

        Processo p1 = new Processo("P1", 7, 0, "AGUARDANDO");
        Processo p2 = new Processo("P2", 4, 0, "AGUARDANDO");
        Processo p3 = new Processo("P3", 5, 1, "AGUARDANDO");
        Processo p4 = new Processo("P4", 6, 2, "AGUARDANDO");
        Processo p5 = new Processo("P5", 3, 4, "AGUARDANDO");

        Processo[] processos = {p1, p2, p3, p4, p5};

        Escalonador escalonador = new Escalonador(pausaHabilitada);

        escalonador.checarProcesso(processos);
    }
}